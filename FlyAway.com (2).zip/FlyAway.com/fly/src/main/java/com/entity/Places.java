package com.entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Places {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("mysql driver not found");
		}
		Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Tables", "root", "boigantsom@2023");
			
			String query = "select PlacesId, Place_Name from places";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
			int id = rs.getInt("PlacesId");
			String Place_Name = rs.getString("Place_Name");		
			
		
			System.out.format("%s, %s, %s, \n", PlacesId,Place_Name);
			}
			st.close();}
			catch (SQLException e) {
			System.out.println("not connected");
		} finally {
			try {
			if(conn != null) {
			
			{conn.close();}
			
			catch(SQLException e) {
				e.printStackTrace();}
			
		}



		
		
	}
}
	}

